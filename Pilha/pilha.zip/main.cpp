/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <cstdlib>
#include <iostream>

using namespace std;

class PilhaDeArray
{
      private:
             // Encapsulamento
             int *VET;
             // Encapsulamento
             int ProximaPosicaoLivre;
             // Tem que ser privado para não ter divergência, devido ao uso dele no decorrer do código
             int MAX;
      public:
             // Construtor
             PilhaDeArray(int qtde)
             {
                 MAX = qtde;
                 // Atribuindo um vetor ao ponteiro VET 
                 VET = new int[MAX];
                 // Está se referindo aos índices do vetor
                 ProximaPosicaoLivre = 0;
             }
             
             void Empilha(int n)
             {  
                    // Para não sair das estremidades do array
                  if(ProximaPosicaoLivre < MAX) 
                    // Primeiro ele executa e depois incrementa
			        VET[ProximaPosicaoLivre++] = n;
             }
             
             void Mostra()
             {
                    // Só varre o vetor
                  for(int i = 0; i<ProximaPosicaoLivre; i++)
                  {
                          cout <<VET[i] <<"\n";
                  }
             }
             
             int Desempilha()
             {
                  if(ProximaPosicaoLivre > 0) 
                    // Primeiro decrementa e depois executa
			        return VET[--ProximaPosicaoLivre];
             }
};

int main(int argc, char *argv[])
{
    PilhaDeArray pilha(50);
    pilha.Empilha(3);
    pilha.Empilha(5);
    pilha.Empilha(7);
    pilha.Empilha(1);
    pilha.Mostra();
    cout <<"\nDesempilha " <<pilha.Desempilha() <<".\n\n";
    cout <<"\nDesempilha " <<pilha.Desempilha() <<".\n\n";
    pilha.Mostra();
    
    return 0;
}

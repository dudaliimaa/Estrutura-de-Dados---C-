/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class No{
    
    public:
    
    No *proxNo;
    int dado;
    
    No ()
      {
           proxNo = NULL;
      }
            
      bool UltimoNo ()
      {
         return (proxNo == NULL);  
      }      
};

class Pilha{
      
      No *topo;
      
      public:
             
      Pilha ()
      {
            topo = NULL;
      }
      
      bool PilhaVazia()
      {
         return (topo == NULL);  
      }
      
      void Empilha (int NovoDado)
      {
          No *novoNo = new No();
          novoNo->dado = NovoDado;
          novoNo->proxNo = topo;
          topo = novoNo;
      }
      
      int Desempilha()
      {
          int temp_Dado = 0;
          No *temp_proxNo = NULL;
          
          if ( PilhaVazia()== false){
                    
                    temp_Dado = topo->dado;
                    temp_proxNo = topo->proxNo;
          
                    delete topo; 
                    topo  = temp_proxNo; 
          }
          return temp_Dado;
          
          
      }   
      
      
};
int main(int argc, char *argv[])
{
    
    Pilha p;
    cout << p.PilhaVazia()<<"\n";
    p.Empilha(5);
   
    p.Empilha(8);
    p.Empilha(10);
    p.Empilha(15);
    cout <<"Dado desempilhada: "<< p.Desempilha()<< "\n";
    cout <<"Dado desempilhada: "<< p.Desempilha()<< "\n";
     cout <<"Dado desempilhada: "<< p.Desempilha()<< "\n";
      cout <<"Dado desempilhada: "<< p.Desempilha()<< "\n";
      cout << p.PilhaVazia()<<"\n";
   
    
  
    
    return 0;
}